package com.example.akashcsc
import android.app.Activity
import android.os.Bundle
import android.webkit.WebView
class MainActivity:Activity(){override fun onCreate(b:Bundle?){super.onCreate(b);val w=WebView(this);w.settings.javaScriptEnabled=true;w.loadUrl("file:///android_asset/index.html");setContentView(w)}}